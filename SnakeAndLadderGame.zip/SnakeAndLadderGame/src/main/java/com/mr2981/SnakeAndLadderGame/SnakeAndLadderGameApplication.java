package com.mr2981.SnakeAndLadderGame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SnakeAndLadderGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(SnakeAndLadderGameApplication.class, args);
	}

}
