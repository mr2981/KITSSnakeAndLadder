package com.mr2981.SnakeAndLadderGame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnakeAndLadderGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
